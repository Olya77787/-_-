﻿namespace demoekz
{


    partial class demoekzDataSet
    {
        partial class FeedbackDataTable
        {
        }

        partial class Repair_RequestDataTable
        {
        }
    }
}
